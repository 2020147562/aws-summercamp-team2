import boto3
import uuid
import json
import cgi
import io
import base64
from datetime import datetime

def lambda_handler(event, context):
    # S3와 DynamoDB 클라이언트 생성
    s3 = boto3.client('s3')
    dynamodb = boto3.resource('dynamodb')
    
    # S3 버킷 이름
    s3_bucket_name = 'team2-images-bucket'
    
    # DynamoDB 테이블 이름
    dynamodb_table_name = 'team2-image-metadata-table'
    
    # Content-Type 헤더를 추출
    content_type = event['headers'].get('Content-Type') or event['headers'].get('content-type')
    
    # 멀티파트 데이터 파싱
    if content_type and content_type.startswith('multipart/form-data'):
        body = event['body']
        if event['isBase64Encoded']:
            body = base64.b64decode(body)
        
        environ = {
            'REQUEST_METHOD': 'POST',
            'CONTENT_TYPE': content_type,
            'CONTENT_LENGTH': str(len(body))
        }
        
        fs = cgi.FieldStorage(fp=io.BytesIO(body), environ=environ, keep_blank_values=True)
        
        # 이미지 파일과 메타데이터 추출
        photo = fs['image']
        metadata_json = fs['metadata'].value
        
        # 메타데이터를 파싱하여 딕셔너리로 변환
        metadata = json.loads(metadata_json)
        comment = metadata.get('comment', '')
        
        if photo.filename:
            image_bytes = photo.file.read()
            # 고유한 이미지 파일 이름 생성
            image_file_name = f"{uuid.uuid4()}.jpg"
            
            # S3에 이미지 업로드
            s3.put_object(
                Bucket=s3_bucket_name,
                Key=image_file_name,
                Body=image_bytes,
                ContentType=photo.type
            )
            
            # 업로드된 이미지의 S3 URL 생성
            s3_image_url = f"https://{s3_bucket_name}.s3.amazonaws.com/{image_file_name}"
            
            # 현재 시간
            timestamp = datetime.utcnow().isoformat()
            
            # DynamoDB에 메타데이터 저장
            table = dynamodb.Table(dynamodb_table_name)
            table.put_item(
                Item={
                    'id': str(uuid.uuid4()),  # 고유 ID
                    'image_url': s3_image_url,
                    'metadata': metadata,
                    'uploaded_at': timestamp
                }
            )
            
            # 성공적인 응답 반환
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'message': 'Image uploaded and metadata stored successfully',
                    'image_url': s3_image_url
                })
            }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'No image file uploaded'})
            }
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Invalid content type'})
        }
