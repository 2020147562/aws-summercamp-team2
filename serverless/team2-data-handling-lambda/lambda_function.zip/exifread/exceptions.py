class InvalidExif(Exception):
    pass


class ExifNotFound(Exception):
    pass
